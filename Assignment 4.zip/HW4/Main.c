/*
 * Filename     Main.c                                                                                                    
 * Date         10/20/2020                                                                                                
 * Author       Zainab Anwar
 * Email        zxa180005@utdallas.edu                                                                                    
 * Course       CS 3377.002 Fall 2020                                                                                     
 * Version      1.0                                                                                                       
 * Copyright 2020, All Rights Reserved                                                                                    
 *                                                                                                                        
 * Description                                                                                                            
 *                                                                                                                        
 * A file that prints out the stdout in parser mode,
 * scans the input text file, and outputs each token given.
 *
 */

#include <string.h>
#include <stdio.h> /* needed for printf() */
#include <stdlib.h>
#include "y.tab.h"

int yyparse (void);
int yylex(void);
extern char *yytext;

int main(int argc, char *argv[])
{

  if(strcmp(argv[0], "./parser") == 0)
    {
   printf("\nOperating in parse mode\n\n");
   
   switch (yyparse())
    {
    case 0:
      printf("\nParse Successful!\n");
      break;
    case 1:
      printf("\nParse Failed!\n");
      break;
    case 2:
      printf("\nOut of Memory\n");
      break;
    default:
      printf("\nUnknown result from yyparse()\n");
      break;
    }
    }
  else if(strcmp(argv[0], "./scanner") == 0)
    {
     printf("\nOperating in scan mode\n\n");
     int token;
     token = yylex();
     while(token != 0)
       {
	 printf("yylex returned ");

      switch(token)
        {
	case NAME_INITIAL_TOKEN:
          printf("NAME_INITIAL_TOKEN token");
          printf(" (%s)\n", yytext);
          break;
        case NAMETOKEN:
          printf("NAMETOKEN token");
	  printf(" (%s)\n", yytext);
          break;
	case EOLTOKEN:
          printf("EOLTOKEN token");
          printf(" (%d)\n", token);
          break;
	case INTTOKEN:
          printf("INTTOKEN token");
          printf(" (%s)\n", yytext);
          break;
	case HASHTOKEN:
          printf("HASHTOKEN token");
          printf(" (%d)\n", token);
          break;
	case COMMATOKEN:
          printf("COMMATOKEN token");
          printf(" (%d)\n", token);
          break;
	case ROMANTOKEN:
          printf("ROMANTOKEN token");
          printf(" (%d)\n", token);
          break;
	case DASHTOKEN:
          printf("DASHTOKEN token");
          printf(" (%d)\n", token);
          break;
        case IDENTIFIERTOKEN:
          printf("IDENTIFIERTOKEN token");
	  printf(" (%s)\n", yytext);         
	  break;
        case SRTOKEN:
          printf("SRTOKEN token");
	  printf(" (%s)\n", yytext);
          break;
        case JRTOKEN:
          printf("JRTOKEN token");
	  printf(" (%s)\n", yytext);
          break;
        default:
          printf("UNKNOWN token");
	  break;        
	}
          token = yylex();
       }
  printf("Scan Done\n");
    } 
  else
    {
      return 0;
    }
}
