#ifndef _HEADER_
#define _HEADER_
/*                                                                                                     
 *                                                                                                     
 * Filename:            header.h                                                                    
 * Date:                10/20/2020                                                                     
 * Author:              Zainab Anwar                                                                
 * Email:               zxa180005@utdallas.edu                                                   
 * Version:             1.0                                                                            
 * Copyright:           2020, All Rights Reserved                                                      
 *                                                                                                     
 * Description:                                                                                        
 *                                                                                                     
 * A header file that includes all files and has function prototypes.
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "y.tab.h"

int yyparse (void);
int yylex(void);
extern char *yytext;
void yyerror(char *);

#endif
